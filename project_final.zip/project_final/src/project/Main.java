package project;

public class Main {

	public static final int SCREEN_WIDTH = 992;
	public static final int SCREEN_HEIGHT = 557;
	
	public static void main(String[] args) throws InterruptedException
	{		
		int win_Lv = 0;	// �¸��� ������ �� ����		
		
		while(win_Lv == 0)
		{
			win_Lv++;
			startPanel start = new startPanel();
			
			while(true) 
			{
				if(start.start)
				{
					start.start = true;
					break;
				}
			}
		
			if(start.start)
			{
				while(win_Lv > 0 && win_Lv <= 1) 
				{		
					Level1Panel game_Lv1 = new Level1Panel();
			
					// 2�ܰ� ����
					if(game_Lv1.win_Lv1 == true) 
					{
						win_Lv++;	// Lv1 �̱�� win_Lv ���� 2�� ��.
						Level2panel game_Lv2 = new Level2panel();
				
						if(game_Lv2.win_Lv2 == true) 
						{
							win_Lv++;	// Lv2 �̱�� win_Lv ���� 3�� ��.
							gameover go = new gameover();
							while(true) 
							{
								if(go.restart)
								{
									win_Lv = 0;
									go.restart = false;
									break;
								}
							}
						}
					}
				
					if (win_Lv > 0 && win_Lv <= 2) 
					{	// Lv1, Lv2 �� �� ���� �� �۵�
						gameover go = new gameover();
						while(true) 
						{
							if(go.restart)
							{
								win_Lv = 1;
								go.restart = false;
								break;
							}
						}
					}		
				}
			}
		}
	}
}