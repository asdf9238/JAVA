package project;

public interface Playing {
	   public void background();
	   public void score_lbl_set();
	   public void stop_btn_set();
	   public void teacher_btn_set();
	   public void player_btn_set();
	   public void danger_btn_set();
	   public void game();
}
